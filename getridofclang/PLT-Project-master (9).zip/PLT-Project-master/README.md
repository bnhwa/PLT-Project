![alt text](bin/xirtamLogo.png)

(Logo Designed by Bailey Hwa)

# XIRTAM Programming Language:



Bailey Nozomu Hwa( bnh2128)

Shida Jing( sj2670) 

Andrew Peter Yevsey Gorovoy( apg2165) 

Annie Wang ( aw3168) 
Lior Attias (lra2135) 

## About

Xirtam is a language meant to work with matrices, done for Prof. Edwards's 2021 Spring PLT class